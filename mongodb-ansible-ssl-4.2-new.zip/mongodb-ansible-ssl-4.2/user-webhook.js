ip="{{ p_hostname }}"
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "rootAdmin",
    pwd: "{{ rootAdmin }}",
    roles: [ { role: "root", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "dba",
    pwd: "{{ dba }}",
    roles: [ { role: "backup", db: "admin" },{ role: "restore", db: "admin" },{ role: "clusterMonitor", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/builtio_webhooks`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "builtio_webhooks" } ]
  }
)
db = connect(`${ip}:27017/cs_usage`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "cs_usage" } ]
  }
)
db = connect(`${ip}:27017/dj_rawcms_production`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "dj_rawcms_production" } ]
  }
)

