ip="{{ p_hostname }}"
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "rootAdmin",
    pwd: "{{ rootAdmin }}",
    roles: [ { role: "root", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "dba",
    pwd: "{{ dba }}",
    roles: [ { role: "backup", db: "admin" },{ role: "restore", db: "admin" },{ role: "clusterMonitor", db: "admin" } ]
  }
)

db = connect(`${ip}:27017/assignments`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "assignments" } ]
  }
)
db = connect(`${ip}:27017/cs_audit_logs`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "cs_audit_logs" } ]
  }
)  
db = connect(`${ip}:27017/cs_discussions`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "cs_discussions" } ]
  }
)
db = connect(`${ip}:27017/cs_jobs_db`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "cs_jobs_db" } ]
  }
)
db = connect(`${ip}:27017/cs_notification`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "cs_notification" } ]
  }
)
db = connect(`${ip}:27017/cs_publish_logs`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "cs_publish_logs" } ]
  }
)
db = connect(`${ip}:27017/recent_searches`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "recent_searches" } ]
  }
)
