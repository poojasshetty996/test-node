ip="{{ p_hostname }}"
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "rootAdmin",
    pwd: "{{ rootAdmin }}",
    roles: [ { role: "root", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/admin`)
db.createUser(
  {
    user: "dba",
    pwd: "{{ dba }}",
    roles: [ { role: "backup", db: "admin" },{ role: "restore", db: "admin" },{ role: "clusterMonitor", db: "admin" } ]
  }
)
db = connect(`${ip}:27017/rawcms_production`)
db.createUser(
  {
    user: "appUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "rawcms_production" } ]
  }
)
db = connect(`${ip}:27017/auth-db`)
db.createUser(
  {
    user: "migrationUser",
    pwd: "{{ appUser }}",
    roles: [ { role: "readWrite", db: "auth-db" } ]
  }
)
